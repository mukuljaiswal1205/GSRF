<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'Home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

//Routes for root directory of website

$route['AboutUs'] = 'Home/AboutUs';
$route['CompanyProfile'] = 'Home/CompanyProfile';
$route['Analysis_of_Raw_Material'] = 'Home/Analysis_of_Raw_Material';
$route['Research_and_Development'] = 'Home/Research_and_Development';
$route['Consultancy_Bureau'] = 'Home/Consultancy_Bureau';
$route['Training'] = 'Home/Training';
$route['Contact_Us'] = 'Home/Contact_Us';
$route['Blog_detail/(:num)'] = 'Home/Blog_detail';
$route['News'] = 'Home/News';
//Routes for the weserve the pages

$route['food-and-feed-testing'] = 'Weserve/food_feed_testing';
$route['environmental_testing'] = 'Weserve/environmental_testing';
$route['BioPharma_Services'] = 'Weserve/BioPharma_Services';
$route['Clinical_diagnosist'] = 'Weserve/Clinical_diagnosist';
$route['Agroscience_services'] = 'Weserve/Agroscience_services';
$route['Forensic_Services'] = 'Weserve/Forensic_Services';
$route['Agro_testing'] = 'Weserve/Agro_testing';
$route['Technologies'] = 'Weserve/Technologies';
$route['genomic_services'] = 'Weserve/genomic_services';
$route['cosmetics'] = 'Weserve/cosmetics';
$route['Consumer_Product_Testing'] = 'Weserve/Consumer_Product_Testing';
$route['Material_and_Engineering_Sciences'] = 'Weserve/Material_and_Engineering_Sciences';
 

//Routes for the Admin Panel 


$route['Admin'] = 'Admin/Home';
$route['Admin/Add_New_Post'] ='Admin/Post_controller/Add_New_Post';
$route['Admin/All_Post'] = 'Admin/Post_controller/All_Post';
$route['Admin/Edit_Post/(:num)'] = 'Admin/Post_controller/Edit_Post/';
$route['Admin/Delete_Post/(:num)'] = 'Admin/Post_controller/Delete_Post';
$route['Admin/Add_New_Post_data'] = 'Admin/Post_controller/Add_New_Post_data';
