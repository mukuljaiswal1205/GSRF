<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
		$this->load->model('Post');
		$data['rows'] = $this->Post->All_Post();
		$this->load->view('Header');
		$this->load->view('Home',$data);
		$this->load->view('Footer');
	}
	public function AboutUs()
	{
		$this->load->view('Header');
		$this->load->view('AboutUs');
		$this->load->view('Footer');
	}
	public function CompanyProfile()
	{
		$this->load->view('Header');
		$this->load->view('CompanyProfile');
		$this->load->view('Footer');
	}
	Public function Analysis_of_Raw_Material()
	{
		$this->load->view('Header');
		$this->load->view('Analysis_of_Raw_Material');
		$this->load->view('Footer');
	}
	public function Research_and_Development()
	{
		$this->load->view('Header');
		$this->load->view('Research_and_Development');
		$this->load->view('Footer');
	}
	public function Consultancy_Bureau()
	{
		$this->load->view('Header');
		$this->load->view('Consultancy_Bureau');
		$this->load->view('Footer');
	}
	public function Training()
	{
		$this->load->view('Header');
		$this->load->view('Training');
		$this->load->view('Footer');
	}
	public function Contact_Us()
	{
		$this->load->view('Header');
		$this->load->view('Contact_Us');
		$this->load->view('Footer');
	}
	
	public function Blog_detail()
	{ 
		$id = $this->uri->segment('2'); 
		$this->load->model('Post');
		$data['row'] = $this->Post->Get_data_by_id($id);
		$data['Posts'] = $this->Post->All_Post();
		$this->load->view('Header');
		$this->load->view('Blog_detal',$data);
		$this->load->view('Footer');
	}
	
	Public function News()
	{
		$this->load->model('Post');
		$data['rows'] = $this->Post->All_Post();
		$this->load->view('Header');
		$this->load->view('News',$data);
		$this->load->view('Footer');
	}
	

}
