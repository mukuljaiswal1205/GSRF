<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
		$All_Posts['Posts'] = $this->Post->All_Post();
	 
		
		$this->load->view('Admin/Header');
		$this->load->view('Admin/Post/All_Post', $All_Posts);
		$this->load->view('Admin/Footer');
		 
	}
	
	 
}
