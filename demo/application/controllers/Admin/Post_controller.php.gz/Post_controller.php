<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Post_controller extends CI_Controller
 {
	
	//Load the view for add new page 
	
	public function Add_New_Post()
	{
		$this->load->view('Admin/Header');
		$this->load->view('Admin/Post/Add_New_Post');
		$this->load->view('Admin/Footer');
       
              	   
	}
	
	// Load the view for the All Post
	
	public function All_Post()
	{
		
		$All_Posts['Posts'] = $this->Post->All_Post();
	 
		
		$this->load->view('Admin/Header');
		$this->load->view('Admin/Post/All_Post', $All_Posts);
		$this->load->view('Admin/Footer');	 
	}
	
	// Load the view  for edit Post 
	
	public function Edit_Post()
	{
		 
		$id = $this->uri->segment(3);
		$data['Post'] = $this->Post->Get_data_by_id($id);
		$this->load->view('Admin/Header');
		$this->load->view('Admin/Post/Edit_Post',$data);
		$this->load->view('Admin/Footer');	
 	
	}
	
	// add new post to the data base 
	
	Public function Add_New_Post_data()
	{
		$this->form_validation->set_rules('Title', 'Title', 'required');
		$this->form_validation->set_rules('Description', 'Description', 'required');
		       if ($this->form_validation->run() == FALSE)
                {
                        $this->load->view('Admin/Header');
		                $this->load->view('Admin/Post/Add_New_Post');
		                $this->load->view('Admin/Footer');
                }
                else
                {
					 $formArray['title'] = $this->input->Post('Title');
                     $formArray['content'] = $this->input->Post('Description');
					 $Image = $_FILES['image']['name'];
					 
					 if(!empty($Image))
					 {
						 $extention  = explode(".",$Image);
						 $Image = "User_Profile.".end($extention); 
						 $formArray['Image'] = $Image;
					 }
					 $result = $this->Post->Insert_Post($formArray);
					if($result)
					{
					     $id = $this->Post->get_last_inserted_id();
					     mkdir("./asserts/Post/".$id);
						 $config['upload_path']   = './asserts/Post/'.$id;
						 $config['allowed_types'] = 'gif|jpg|png|jpeg';
						 $config['max_size']      = '1000';
						 $config['max_width']     = '1024';
						 $config['max_height']    = '768';
						 $config['file_name']     = $Image;
						 $this->load->library('upload', $config);
						 if ( ! $this->upload->do_upload('image'))
						{
							 $error = array('error' => $this->upload->display_errors()); 
							 $this->session->set_flashdata('Error','<div class="alert alert-info text-center">User Successfully Registerd But User Profile is Misssing!</div>'); 
							 redirect('/Admin/All_Post'); 
						}	
						else
						{
							$this->session->set_flashdata('Success','<div class="alert alert-success text-center">User Successfully Registered!</div>');
							redirect('/Admin/All_Post'); 
						}					 
				    }
				    else
					{
						$this->session->set_flashdata('Error','<div class="alert alert-warning text-center">Errer with comminicate with database!</div>');
						redirect('/Admin/Add_New_Post');
					}	 
                }
	}
	
	//Update the Post data to the database and redirect the user to the All Post page  
	
	Public function Update_Post()
	{
		 $id = $this->input->post('ID');
		 $formArray['title']   = $this->input->post('Title');
		 $formArray['content'] = $this->input->post('Description');
		 $Image = $_FILES['image']['name'];			 
		 if(!empty($Image))
		    {
				 $extention  = explode(".",$Image);
				 $Image = "User_Profile.".end($extention); 
				 $formArray['Image'] = $Image;
			  
				 //image configuration 
				 $config['upload_path']   = './asserts/Post/'.$id;
				 $config['allowed_types'] = 'gif|jpg|png|jpeg';
				 $config['max_size']      = '1000';
				 $config['max_width']     = '1024';
				 $config['max_height']    = '768';
				 $config['overwrite']     = 'True';
				 
				 $this->load->library('upload', $config);
				 if(($this->upload->do_upload('image')))
				 {
					 $formArray['Image'] = $this->upload->data('file_name');
				 }
				 else
				 {
					 $error = $this->upload->display_errors();
					 $this->session->set_flashdata('Error','<div class="alert alert-success text-center">'.$error.'!</div>');
					 redirect('/Admin/All_Post'); 
				 } 
		    }	 
		 $result = $this->Post->Update_Post($id,$formArray);
		 if($result)
		 {
			$this->session->set_flashdata('Success','<div class="alert alert-success text-center">User Successfully Update!</div>');
			redirect('/Admin/All_Post'); 
		 }
		 else 
		 {
			 $this->session->set_flashdata('Error','<div class="alert alert-warning text-center">Errer with comminicate with database!</div>');
			 redirect('/Admin/All_Post');
		 }
	}
	
	
	//Delete the post form the database
	
	public function Delete_Post()
	{
		$id = $this->uri->segment(3);
		$this->Post->Delete_Post($id);
		$this->session->set_flashdata('Success','<div class="alert alert-success text-center">User successfully Deleted!</div>');
		redirect('/Admin/All_Post');
	}
}



