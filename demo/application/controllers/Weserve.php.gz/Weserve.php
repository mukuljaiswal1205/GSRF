<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Weserve extends CI_Controller {

 
	public function food_feed_testing()
	{
		$this->load->view('Header');
		$this->load->view('Weserve/food_feed_testing');
		$this->load->view('Footer');
	}
	public function environmental_testing()
	{
		$this->load->view('Header');
		$this->load->view('Weserve/environmental_testing');
		$this->load->view('Footer');
	}
	public function BioPharma_Services()
	{
		$this->load->view('Header');
		$this->load->view('Weserve/BioPharma_Services');
		$this->load->view('Footer');
	}
	Public function Clinical_diagnosist()
	{
		$this->load->view('Header');
		$this->load->view('Weserve/Clinical_diagnosist');
		$this->load->view('Footer');
	}
	public function Agroscience_services()
	{
		$this->load->view('Header');
		$this->load->view('Weserve/Agroscience_services');
		$this->load->view('Footer');
	}
	public function Forensic_Services()
	{
		$this->load->view('Header');
		$this->load->view('Weserve/Forensic_Services');
		$this->load->view('Footer');
	}
	public function Agro_testing()
	{
		$this->load->view('Header');
		$this->load->view('Weserve/Agro_testing');
		$this->load->view('Footer');
	}
	public function Technologies()
	{
		$this->load->view('Header');
		$this->load->view('Weserve/Technologies');
		$this->load->view('Footer');
	}
	public function genomic_services()
	{
		$this->load->view('Header');
		$this->load->view('Weserve/genomic_services');
		$this->load->view('Footer');
	}
	
	public function cosmetics()
	{
		$this->load->view('Header');
		$this->load->view('Weserve/cosmetics');
		$this->load->view('Footer');
	}
	
	public function Consumer_Product_Testing()
	{
		$this->load->view('Header');
		$this->load->view('Weserve/Consumer_Product_Testing');
		$this->load->view('Footer');
	}
	public function Material_and_Engineering_Sciences()
	{
		$this->load->view('Header');
		$this->load->view('Weserve/Material_and_Engineering_Sciences');
		$this->load->view('Footer');
	}
}
