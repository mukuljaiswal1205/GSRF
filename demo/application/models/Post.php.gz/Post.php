<?php 
class Post extends CI_Model {

         public function __construct()
        {
            parent::__construct();
        }
		
		public function All_Post()
        {
                $this->db->select('*');
                $this->db->order_by("id","desc");
                $this->db->from('News');
                $query=$this->db->get();
                return $query->result_array();
					
        }
		
		Public function Get_data_by_id($id)
		{
			$this->db->Select('*');
			$this->db->from('News');
			$this->db->where('id',$id);
			$query = $this->db->get();
			return $query->row_array();
			
		}
        
		public function Delete_Post($id)
		{
			$query = $this->db->where('id',$id)->Delete('News');
			return $query;
		}
		
		public function Insert_Post($formArray)
		{
		    $data = $this->db->insert('News',$formArray);
		    return $data;
		}
		
		public function Update_Post($id,$formArray) 
		{
            $this->db->where('id', $id);
            $result = $this->db->update('News', $formArray);
			return $result;
        }
		
		Public function get_last_inserted_id()
		{
			$id = $this->db->insert_id();
			return $id;
		}



}
?>