 
<style>
ul, li {

   
}
.about-style-three {
    
    padding: 50px 0px 50px 0px;
}
</style>
    <!-- page-title -->
    <section class="page-title centred" style="background-image: url(<?php echo base_url('asserts/images/background/page-title.jpg'); ?>);">
        <div class="container">
            <div class="content-box">
                <div class="title"> About us</div>
                <ul class="bread-crumb">
                    <li><a href="index.html">Home</a></li>
                    <li>About us </li>
                </ul>
            </div>
        </div>
    </section>
    <!-- page-title end -->


    <!-- about-style-mission -->
    <section class="about-style-three">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 title-column">
                    <div class="title-box">
                        <div class="sec-title" style="margin-bottom:2px;">Mission Of GSRF</div>
                        <div class="title-text">About us</div>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 content-column">
                    <div class="content-box">
                       
                        <div class="text" style="margin-top:25px;"> 
						  <ul>
						    <li style="list-style: disc;">To make really significant contributions to the nation’s progress     in various
                            realms of scientific and industrial research.</li>
							<li style="list-style: disc;">To undertake, aid, assist, conduct, carry on or help to carry on research for the
                              extension of  knowledge in  the fields  of natural, applied  and  bio sciences,
                              industrial and  environmental research,  more particularly in the fields of Food
                              science, Plant Science, Biotechnology and allied areas. </li>

						  </ul>
						</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- about-style-mission end -->
	   
	<!-- about-style-vision  -->
     <section class="about-style-three" style="background: #eaeaea57;" >
        <div class="container"  >
             <div style="text-align:center;">
			            
			 </div>
			<div class="row">
			
                <div class="col-lg-5 col-md-5 col-sm-12 title-column">
                    <div class="title-box">
					 <div class="sec-title" style="margin-bottom:2px;">Vision Of GSRF</div>
                        <div class="title-text"  >About us</div>
                         <figure class="image-box" style="margin-top:45px;" >
                            <img src="<?php echo base_url('asserts/images/aboutus/our vision.jpg'); ?>" style="width:100%"alt="">
                             
                        </figure>
                    </div>
                </div>
                <div class="col-lg-7 col-md-7 col-sm-12 content-column">
                    <div class="content-box">
                     
                        <div class="text"> 
						  <ol>
 
 
<li style="list-style: decimal;"> To critically evaluate the knowledge gaps of scientific and industrial community
on   a   continuous   basis,   and   recognize   essential   areas   for   research   and
development.</li>
<li style="list-style: decimal;"> To achieve new milestones of   	innovative research   	having its core focus on
providing a backbone to the  	natural, industrial, biological and   environmental
research,   	  for proper utilization of the advancements in these by bringing
together students, professional, academics, organizations through consultative,
advisory,   educative   process   which   will   provide   growth   and   partnership
opportunities for organizations, academics, students and the society and nation as
a whole.</li>
<li style="list-style: decimal;"> To initiate the application of basic research findings to specific application
involving the devising of specified novel products, experimental production and
testing of devices, raw materials, equipments, procedure and processes.</li>
<li style="list-style: decimal;"> To   develop     kits   like  	GMO   Detection   Kit	,  Allergen   Detection   Kit	,   Milk
Adulteration detection kit	, Plant Pathogen Detection Kits, Animal Species Id
detection Kits, Food Allergen Detection Kits, Basmati- Non Basmati Detection
Kit etc.​</li>
<li style="list-style: decimal;"> To create technology and process improvement related knowledge for the benefit
of industry, general consumers and environment, in particular processing of
edible oils, cereals, pulses, vegetables, fruits and other foods and food products,
investigation into the usability and improvement of raw materials used in food
industries.</li>
<li style="list-style: decimal;"> To provide efficient, accurate, knowledge and experience based  testing service
for the Food , Cosmetics, , Animal Feed, Agriculture & allied Industries. </li>

						  </ul>
						</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- about-style-vision  end -->
	 <!-- about-style-mission -->
    <section class="about-style-three">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 title-column">
                    <div class="title-box">
                        <div class="sec-title" style="margin-bottom:2px;">Our core Team </div>
                        <div class="title-text">About us</div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 content-column">
                    <div class="content-box">
                       
                        <div class="text" style="margin-top:25px;"> 
						  <ul>
						    <li style="list-style: disc;">MR REETESH KUMAR VISHWAKARMA</li>
                            <li style="list-style: disc;"> DR AMITA MISHRA </li>
							<li style="list-style: disc;"> DR PREM GUPTA </li>
							<li style="list-style: disc;"> DR MRS  JAYANTI ADHIKARI </li>
							<li style="list-style: disc;"> MR ASHWANI SHARMA </li>
							<li style="list-style: disc;"> PROF S N NAIK </li>
							 

						  </ul>
						</div>
                    </div>
                </div>
				 <div class="col-lg-6 col-md-6 col-sm-12 content-column">
                    <div class="content-box">
                       
                        <div class="text" style="margin-top:25px;"> 
						  <ul>
						    
							
							 
							<li style="list-style: disc;"> DR SUMIT BURUKUL </li>
							<li style="list-style: disc;"> MS SONALI KOKATE </li>
							<li style="list-style: disc;"> MR SUNIL KUMAR POLIPALLI </li>
							<li style="list-style: disc;"> MR A K JAIN </li>
							<li style="list-style: disc;"> MR S P SINGH  </li>

						  </ul>
						</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
	<!-- about-style-vision  -->
     <section class="about-style-three"  style="background: #eaeaea57;"  >
        <div class="container"  >
             <div style="text-align:center;">
			     <h1>Our Values</h1>      
			 </div>
			<div class="row">
                <div class="col-lg-3 col-md-3 col-sm-12 title-column">
                         <figure class="image-box" style="padding:30px; " >
                            <img src="<?php echo base_url('asserts/images/aboutus/performance.png'); ?>" style="width:100%;padding:30px; padding-bottom:0px; "alt="">
                        </figure>
						<p style="text-align:center;">Efficiency, sincerity and dedication to Research</p>
                </div>
				 <div class="col-lg-3 col-md-3 col-sm-12 title-column">
                         <figure class="image-box" style="padding:30px; " >
                            <img src="<?php echo base_url('asserts/images/aboutus/seo-and-web.png'); ?>" style="width:100%;padding:30px;padding-bottom:0px;"alt="">
                        </figure>
						<p style="text-align:center;">Accuracy, proficiency and client confidentiality</p>
                </div> <div class="col-lg-3 col-md-3 col-sm-12 title-column">
                         <figure class="image-box" style="padding:30px; " >
                            <img src="<?php echo base_url('asserts/images/aboutus/exchange.png'); ?>" style="width:100%;padding:30px;padding-bottom:0px;"alt="">
                        </figure>
						<p style="text-align:center;">Regular updation of information of domestic and global relevance</p>
                </div>
				 <div class="col-lg-3 col-md-3 col-sm-12 title-column">
                         <figure class="image-box" style="padding:30px; " >
                            <img src="<?php echo base_url('asserts/images/aboutus/monitoring.png'); ?>" style="width:100%;padding:30px;padding-bottom:0px;"alt="">
                        </figure>
						<p style="text-align:center;">Integrity and accountability of research and analytical outcome.</p>
                </div>
                
            </div>
        </div>
    </section>

 