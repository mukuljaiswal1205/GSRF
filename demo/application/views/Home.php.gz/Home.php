
<style>
    .slider-style-five .slide {
    padding: 51px 0px 56px 0px;
}
</style>
    <!-- main-slider -->
    <section class="main-slider slider-style-two slider-style-five">
        
        <div class="main-slider-carousel owl-carousel owl-theme">
            
            <div class="slide" style="background-image:url(<?php echo base_url('asserts/images/index/banner1.jpg'); ?>)">
                <div class="bg-column"></div>
                <div class="container">
                    <div class="content-box">
                        <h1>Food & Feed<br> Testing </h1>
                        <div class="text">GSRF is the world leading food and feed testing laboratory group, deploying <br>a comprehensive range of state-of-the-art analytical techniques in order<br> to support its clients' increasingly stringent quality and safety standards.</div>
                        <div class="slider-btn">
                            <a href="Contact_Us.php" class="theme-btn theme-btn-three">Contact Us</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="slide" style="background-image:url(<?php echo base_url('asserts/images/index/banner3.jpg');  ?>)">
                <div class="bg-column"></div>
                <div class="container">
                    <div class="content-box">
                        <h1>Forensic <br>Services</h1>
                        <div class="text">From the analysis of conventional samples (blood, urine and oral fluids)<br> through to the development and analysis of specialist samples (hair and nails),<br> our range of detectable drugs and chemicals is unsurpassed across Europe. More info</div>
                        <div class="slider-btn">
                            <a href="Contact_Us.php" class="theme-btn theme-btn-three">Contact Us</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="slide" style="background-image:url(<?php echo base_url('asserts/images/index/banner2.jpg'); ?>)">
                <div class="bg-column"></div>
                <div class="container">
                    <div class="content-box">
                        <h1>Genomics <br> Science</h1>
                        <div class="text">Excepteur sint occaecat cupidatat non proident, sunt in culpa<br />qui officia deserunt mollit anim id est laborum. sed ut per<br />spiciatis unde omnis natus error.</div>
                        <div class="slider-btn">
                            <a href="Contact_Us.php" class="theme-btn theme-btn-three">Contact Us</a>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </section>
    <!-- main-slider end -->

    <!-- service-section -->
    <section class="service-section style-two">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-12 service-column">
                    <div class="single-service-content inner-box">
                        <figure class="image-box">
                            <img src="<?php echo base_url('asserts/images/index/chemical2.jpg'); ?>" alt="" style="height:200px; width:270px;">
                            <div class="overlay">
                                <div class="wrapper">
                                    <a href="#"><i class="fa fa-link"></i></a>
                                </div>                                    
                            </div>
                        </figure>
                        <div class="lower-content">
                            <h5><a href="#">Food and Feed Testing</a></h5>
                            <div class="text">GSRF is the world leading food and feed testing laboratory group, deploying a comprehensive range of state-of-the-art analytical techniques </div>
                            <div class="link"><a href="food-and-feed-testing.php" class="theme-btn-two">Read More</a></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12 service-column">
                    <div class="single-service-content inner-box">
                        <figure class="image-box">
                            <img src="<?php echo base_url('asserts/images/index/Enviroment.jpg'); ?>" alt="" style="height:200px; width:270px;">
                            <div class="overlay">
                                <div class="wrapper">
                                    <a href="#"><i class="fa fa-link"></i></a>
                                </div>                                    
                            </div>
                        </figure>
                        <div class="lower-content">
                            <h5><a href="#">Environmental testing</a></h5>
                            <div class="text">A clean and safe environment is a pre-requisite for health and quality of life. GSRF contributes to this by providing market-leading laboratory</div>
                            <div class="link"><a href="environmental_testing.php" class="theme-btn-two">Read More</a></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12 service-column">
                    <div class="single-service-content inner-box">
                        <figure class="image-box">
                            <img src="<?php echo base_url('asserts/images/index/BioPharma.jpg'); ?>" alt="" style="height:200px; width:270px;">
                            <div class="overlay">
                                <div class="wrapper">
                                    <a href="#"><i class="fa fa-link"></i></a>
                                </div>                                    
                            </div>
                        </figure>
                        <div class="lower-content">
                            <h5><a href="#">BioPharma Services</a></h5>
                            <div class="text">GSRF is a first-class biopharmaceutical outsourcing services partner (Contract Research Organization - CRO, Contract Development</div>
                            <div class="link"><a href="BioPharma_Services.php" class="theme-btn-two">Read More</a></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12 service-column">
                    <div class="single-service-content inner-box">
                        <figure class="image-box">
                            <img src="<?php echo base_url('asserts/images/index/maxresdefault.jpg'); ?>" alt="" style="height:200px; width:270px;">
                            <div class="overlay">
                                <div class="wrapper">
                                    <a href="#"><i class="fa fa-link"></i></a>
                                </div>                                    
                            </div>
                        </figure>
                        <div class="lower-content">
                            <h5><a href="#">Agro Science</a></h5>
                            <div class="text">We help farmers to collect the right data and providing insight into soil and crop health, fertilisation, feed value and food safety.</div>
                            <div class="link"><a href="Agro_testing.php" class="theme-btn-two">Read More</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- service-section end -->

    <!-- service-style-five -->
    <section class="service-style-five gray-bg">
        <div class="container">
            <div class="title-box centred">
                <div class="sec-title">Our Services</div>
                <div class="top-text">Some Key Points</div>
            </div>
            <div class="products-discription"> 
                <div class="custom-tab-title centred">
                    <ul class="tab-title clearfix">
                        <li data-tab-name="details" class="active">METHODOLOGIES</li>
                        <li data-tab-name="review">RESEARCH & DEVELOPMENT</li>
                        <li data-tab-name="review-2">Advice Bureau</li>
                        <li data-tab-name="review-3">Training</li>
                         
                    </ul>
                </div>
                <div class="tab-details-content">
                    <div class="tab-content" id="details">
                        <div class="single-tab-content">
                            <div class="row">
                                <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                                    <figure class="image-box"><img src="<?php echo base_url('asserts/images/aboutus/appoldt.jpg'); ?>" alt=""></figure>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                                    <div class="content-box">
                                        <div class="title">METHODOLOGIES</div>
                                        <div class="text">
                                            <p>GSRF adheres strictly to Indian and International Standards like AOAC, Codex, BIS, FSSAI, OECD in order to yield accurate and efficient test results with minimum uncertainty levels.</p>
                                            <p>Instruments are Calibrated through authorized agencies</p>
                                        </div>
                                        <div class="link"><a href="#" class="theme-btn">Read More</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-content" id="review">
                        <div class="single-tab-content">
                            <div class="row">
                                <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                                    <figure class="image-box"><img src="<?php echo base_url('asserts/images/index/R&D.jpg'); ?>" alt=""></figure>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                                    <div class="content-box">
                                        <div class="title">RESEARCH & DEVELOPMENT</div>
                                        <div class="text">
                                            <p>GSRF is a research organization, well known for conducting application oriented research aiming at problem solving and innovative
                                            solution. Since its establishment in 1978, GSRF has been actively involved in undertaking research projects assigned by various
                                            Government Departments and industrial organizations, private and public bodies in the fields of oil and oil-based products, animal feed,
                                            food and related materials, biofuels, oil substitutes etc.
                                            Research was conducted on food safety and nutrition,</p>
                                        </div>
                                        <div class="link"><a href="Research_and_Development.php" class="theme-btn">Read More</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-content" id="review-2">
                        <div class="single-tab-content">
                            <div class="row">
                                <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                                    <figure class="image-box"><img src="<?php echo base_url('asserts/images/index/homepage-banner_final.jpg'); ?>" alt=""></figure>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                                    <div class="content-box">
                                        <div class="title">Advice Bureau</div>
                                        <div class="text">
                                            <p>GSRF acts also as information and advice bureau by offering consultancy service in the form of status /feasibility 
                                            reports, information papers, problem diagnosis, devising cost-effective solutions and updating the latest R&D findings
                                            Our consultancy Division has been able in making food manufacturers and retailers aware of all the technical
                                            specifications and testing requirements and solve specific queries</p>
                                        </div>
                                        <div class="link"><a href="Consultancy_Bureau.php" class="theme-btn">Read More</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-content" id="review-3">
                        <div class="single-tab-content">
                            <div class="row">
                                <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                                    <figure class="image-box"><img src="<?php echo base_url('asserts/images/index/1653-X3.jpg'); ?>" alt=""></figure>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                                    <div class="content-box">
                                        <div class="title">Training</div>
                                        <div class="text">
                                            <p>Objective of Training programme is to provide fundamental concepts of routine and advanced
                                            techniques in analytical techniques, thorough practical experience in performing analysis and information
                                            regarding standard specifications, statutory requirements . ​Fresh graduates and postgraduates either employed 
                                            or unemployed may apply. Programme is designed to prepare the trainees in their ability to perform various testing
                                            methods with confidence. The present training programme are conducted
                                            through lectures and practical hands-on training in the laboratory.</p>
                                        </div>
                                        <div class="link"><a href="Consultancy_Bureau.php" class="theme-btn">Read More</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </section>
    <!-- service-style-five end -->

    
    <!-- cta-section end -->


    <!-- about-style-eight -->

    <!-- about-style-eight -->



    <!-- news-style-two -->
    <section class="news-style-two">
        <div class="container">
            <div class="title-box centred">
                <div class="sec-title">News</div>
                <div class="top-text">Latest News</div>
            </div>
            <div class="row">
			<?php 
			    $count = 0;
				foreach($rows as $row)
				{
					 $count = $count + 1;
					 if($count > 3)
					 {
						 break;
					 }
				?>
				
					<!--Start single blog post-->
					<div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
						<div class="single-blog-post">
							<div class="img-holder">
								<img width="100%" height="250px" src="<?php echo base_url(); ?>asserts/Post/<?php echo $row['id']."/".$row['Image']; ?>" alt="Awesome Image">
								<div class="categorie-button">
									<a class="btn-one" href="Blog_detail/<?php echo $row['id']; ?>"></a>    
								</div>
							</div>
							<div class="text-holder">
								<div class="meta-box">
									<ul class="meta-info">
										<li>By admin</li>
										<li><a href="Blog_detail/<?php echo $row['id']; ?>"><?php echo nice_date($row['Date'],'d/m/Y'); ?></a></li>
									</ul>    
								</div>
								<h3 class="blog-title"><a href="#"><?php echo $row['title']; ?></a></h3> 
								<div class="text-box">
									<p><?php echo word_limiter($row['content'],20); ?></p>
								</div>
								<div class="readmore-button">
									<a class="btn-two" href="Blog_detail/<?php echo $row['id']; ?>">Continue Reading<span class="flaticon-next"></span></a>
								</div>  
							</div>
						</div>
					</div>
					<!--End single blog post-->
			<?php 		
				}
			?>	
            </div>
        </div>
    </section>
    
    

    <!-- news-section -->
    <section class="news-section gray-bg">
        <div class="container">
            <div class="title-box">
                <div class="sec-title">Our Client's</div>
                <div class="title-text">work with us</div>
            </div>
            <div class="news-content">
                <div class="three-column-carousel">
                    <div class="single-news-content">
                        <figure class="image-box" style="padding:40px;"><img src="https://cdnmedia.eurofins.com/corporate-eurofins/media/12143668/tecna_logo.jpg?width=250&height=73" alt=""></figure>
                    </div>
                    <div class="single-news-content">
                        <figure class="image-box" style="padding:40px;"><img src="https://cdnmedia.eurofins.com/corporate-eurofins/media/12145271/abraxis_logo.png?width=211&height=70" alt=""></figure>
                         
                    </div>
                    <div class="single-news-content">
                        <figure class="image-box" style="padding:40px;"><img src="https://cdnmedia.eurofins.com/corporate-eurofins/media/12145380/ingenesa_logo.png" alt=""></figure>
                         
                    </div>
                    <div class="single-news-content">
                        <figure class="image-box" style="padding:40px;"><img src="https://cdnmedia.eurofins.com/corporate-eurofins/media/12146262/gsd-logo.png" alt=""></figure>
                         
                    </div>
                   
                </div>
            </div>
        </div>
    </section>
    <!-- news-section end -->
    <!-- news-style-two end -->

    <section class="subscribe-section">
        <div class="container">
            <div class="outer-box">
                <div class="row">
                    <div class="title-column col-lg-6">
                        <h2>Subscribe <br>to Our Newsletter</h2>
                    </div>
                    <div class="subscribe-form col-lg-6">
                        <form method="post" action="http://html.tonatheme.com/2019/Aculia/contact.html">
                            <div class="form-group">
                                <input type="email" name="email" value="" placeholder="Your email..." required="">
                                <button type="submit" class="theme-btn btn-style-six">Subscribe Now</button>
                            </div>
                        </form>
                    </div>
                </div> 
            </div>                                   
        </div>
    </section>
    
