<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from html.tonatheme.com/2019/Aculia/index-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 25 Nov 2019 11:39:26 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>GANESH SCIENTIFIC RESEARCH FOUNDATION </title>

<!-- Stylesheets -->
<link href="<?php echo base_url('asserts/css/style.css'); ?>" rel="stylesheet">
<link href="<?php echo base_url('asserts/css/responsive.css'); ?>" rel="stylesheet">
<link rel="icon" href="<?php echo base_url('asserts/images/favicon.ico'); ?>" type="image/x-icon">

</head>
<style>
  .small_logo{
	  height:70px;
  }
  .big_logo{
	  height:100px;
  }
  .header-top {
 
    padding: 12px 0px 15px 0px;
}
.main-footer {
    
    background: #0605098f;
    
}
                                    
 .weserve:hover {
    background: #ff0000;
    border-bottom: 1px dashed #ff0000;
}
.weserve:hover a {
    color: #ffffff;
}
.weserve{
    position: relative;
    width: 100%;
    padding: 7px 30px;
    border-bottom: 1px solid #e5e5e5;
    transition: all 500ms ease;
}
.weserve > a {
    position: relative;
    display: block;
    font-family: 'Open Sans', sans-serif;
    padding: 6px 0px;
    line-height: 24px;
    font-size: 15px;
    color: #222222;
    font-weight: 500;
    text-align: left;
    text-transform: capitalize;
    transition: all 500ms ease;
    -moz-transition: all 500ms ease;
    -webkit-transition: all 500ms ease;
    -ms-transition: all 500ms ease;
    -o-transition: all 500ms ease;
}

</style>
<!-- page wrapper -->
<body class="boxed_wrapper">


    <!-- .preloader -->
     <body class="boxed_wrapper">
    <!-- /.preloader -->


    <!-- Main Header -->
    <header class="main-header">
        <!-- header-top -->
        <div class="header-top">
            <div class="container">
                <div class="clearfix">
                    <div class="logo-box top-left">
                        <figure class="logo-outer "><a href="index.PHP"><img class="big_logo" src="<?php echo base_url('asserts/images/Logo1 GSRF.png'); ?>" alt=""></a></figure>
                    </div>
                    <div class="top-right">
                        <ul class="header-info clearfix">
                            <li><i class="flaticon-contact"></i>gsrfdelhi@gmail.com</li>
                            <li><i class="flaticon-marker"></i>64-65 SATGURU RAM SINGH MARG<br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp KIRTI NAGAR DELHI</li>
                            <li><a href="#" class="theme-btn">Join Research</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div><!-- header-top end -->

        <!-- header-bottom -->
        <div class="header-bottom">
            <div class="container">
                <div class="nav-outer clearfix">
                    <div class="menu-area">
                        <nav class="main-menu navbar-expand-lg">
                            <div class="navbar-header">
                                <!-- Toggle Button -->      
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                </button>
                            </div>
                            <div class="navbar-collapse collapse clearfix">
                                <ul class="navigation clearfix">
                                    <li class="current "><a href="Home">Home</a>
                                    </li>
                                    <li class="dropdown"><a href="#">About</a>
                                        <ul>
                                            <li><a href="AboutUs">About us</a></li>
                                            <li><a href="CompanyProfile">Company Profile</a></li>
                                        </ul>
                                    </li> 
									<li class="dropdown"><a href="#">We Serve</a>
                                        <ul style="width:600px;">
                                           <div class="row" >
                                             <div class="col-md-6">
												 <li class="weserve"><a href="food-and-feed-testing">Food and Feed Testing </a></li>
												 <li class="weserve"><a href="BioPharma_Services">BioPharma Services</a></li>
												 <li class="weserve"><a href="Agroscience_services">Agroscience Services</a></li>
												 <li class="weserve"><a href="Agro_testing">Agro Testing</a></li>
												 <li class="weserve"><a href="genomic_services">Genomic Services</a></li>
												 <li class="weserve" style="border-bottom: 1px solid #e5e5e500;"><a href="Consumer_Product_Testing.php">Consumer Product Testing</a></li>
											 </div>  
                                             <div class="col-md-6">                    
												 <li class="weserve"><a href="environmental_testing">Environment Testing</a></li>
												 <li class="weserve"><a href="Clinical_diagnosist">Clinical Diagnostics</a></li>
												 <li class="weserve"><a href="Forensic_Services">Forensic Services</a></li>
												 <li class="weserve"><a href="Technologies">Technologies</a></li>
												 <li class="weserve"><a href="cosmetics">Cosmetics & Personal Care</a></li>
												 <li class="weserve"><a href="Material_and_Engineering_Sciences">Materials & Engineering Sciences</a></li>
                                             </div> 
                                            
                                            </div>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="#">Services</a>
                                        <ul>
                                            <li><a href="Analysis_of_Raw_Material">Analysis of Raw Material</a></li>
                                            <li><a href="Research_and_Development"> Research and Development</a></li>
											<li><a href="Consultancy_Bureau">Consultancy Bureau</a></li>
											<li><a href="Training">Training</a></li>
											  
											
                                        </ul>
                                    </li> 
                                    <li  ><a href="News">News</a> </li>
                                    <li><a href="Contact_Us">Contact Us</a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div><!-- header-bottom end -->


        <!--Sticky Header-->
        <div class="sticky-header">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-12 col-sm-12 column">
                        <figure class="logo-box "><a href="index.php"><img class="small_logo" src="<?php echo base_url('asserts/images/Logo1 GSRF.png'); ?>"  alt=""></a></figure>
                    </div>
                    <div class="col-lg-8 col-md-12 col-sm-12 menu-column">
                        <div class="menu-area">
                            <nav class="main-menu navbar-expand-lg">
                                <div class="navbar-header">
                                    <!-- Toggle Button -->      
                                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    </button>
                                </div>
                                <div class="navbar-collapse collapse clearfix">
									<ul class="navigation clearfix">
										<li class="current "><a href="Home">Home</a></li>
										<li class="dropdown"><a href="#">About</a>
											<ul>
												<li><a href="AboutUs">About us</a></li>
												<li><a href="CompanyProfile">Company Profile</a></li>
											</ul>
										</li> 
										<li class="dropdown"><a href="#">We Serve</a>
											<ul style="width:600px;">
											   <div class="row" >
												 <div class="col-md-6">
													 <li class="weserve"><a href="food-and-feed-testing">Food and Feed Testing </a></li>
													 <li class="weserve"><a href="BioPharma_Services">BioPharma Services</a></li>
													 <li class="weserve"><a href="Agroscience_services">Agroscience Services</a></li>
													 <li class="weserve"><a href="Agro_testing">Agro Testing</a></li>
													 <li class="weserve"><a href="genomic_services">Genomic Services</a></li>
													 <li class="weserve" style="border-bottom: 1px solid #e5e5e500;"><a href="Consumer_Product_Testing.php">Consumer Product Testing</a></li>
												 </div>  
												 <div class="col-md-6">                    
													 <li class="weserve"><a href="environmental_testing">Environment Testing</a></li>
													 <li class="weserve"><a href="Clinical_diagnosist">Clinical Diagnostics</a></li>
													 <li class="weserve"><a href="Forensic_Services">Forensic Services</a></li>
													 <li class="weserve"><a href="Technologies">Technologies</a></li>
													 <li class="weserve"><a href="cosmetics">Cosmetics & Personal Care</a></li>
													 <li class="weserve"><a href="Material_and_Engineering_Sciences">Materials & Engineering Sciences</a></li>
												 </div> 
												
												</div>
											</ul>
										</li>
										<li class="dropdown"><a href="#">Services</a>
											<ul>
												<li><a href="Analysis_of_Raw_Material">Analysis of Raw Material</a></li>
												<li><a href="Research_and_Development"> Research and Development</a></li>
												<li><a href="Consultancy_Bureau">Consultancy Bureau</a></li>
												<li><a href="Training">Training</a></li>
											</ul>
										</li> 
										<li  ><a href="News">News</a> </li>
										<li><a href="Contact_Us">Contact Us</a></li>
									</ul>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- sticky-header end -->
    </header>
    <!-- End Main Header -->