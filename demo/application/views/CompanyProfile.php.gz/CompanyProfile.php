 

    <!-- page-title -->
    <section class="page-title centred" style="background-image: url(<?php echo base_url('asserts/images/background/page-title.jpg'); ?>);">
        <div class="container">
            <div class="content-box">
                <div class="title">Company Profile</div>
                <ul class="bread-crumb">
                    <li><a href="index.html">Home</a></li>
                    <li>Company Profile</li>
                </ul>
            </div>
        </div>
    </section>
    <!-- page-title end -->

    <!-- about-style-three -->
    <section class="about-style-three">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-12 col-sm-12 title-column">
                    <div class="title-box">
                        <div class="sec-title">GANESH SCIENTIFIC RESEARCH FOUNDATION</div>
                        <div class="title-text">Company Profile</div>
                    </div>
                </div>
                <div class="col-lg-7 col-md-12 col-sm-12 content-column">
                    <div class="content-box">
                        <div class="top-text"  style="text-align:justify;">GANESH SCIENTIFIC RESEARCH FOUNDATION is an independent, no-profit, multidisciplinary analytical, research and development laboratory,</div>
                        <div class="text" style="text-align:justify;">  
functioning in the field of edible oils, oilseeds, oil cakes, oil based products,
spices, food items , animal feed and Biotechnology for the last 40 years. It is
a Public Charitable Irrevocable Trust, registered under the Indian Trust Act,
1882,   GSRF   is   approved   by   Government   of   India,   Ministry   of   Food   &
Consumer Affairs, Department of Sugar & Edible Oils.)
Ganesh Scientific Research Foundation is one of the leading Independent
Research and Analysis Laboratories based in Delhi with 40 years’ reputation
for   high   quality   research,   efficient   and   analysis,   consultancy   and  Training
facilities.     Our   State   of   the   Art   facilities   include   various   sophisticated
Instruments,   complimented   by   a   team   of   qualified   and   experienced
Scientists, Technicians and Analysts.   We have long proven capabilities in
undertaking   research   Projects,   simple,   as   well   as   complicated   testing
assignment and providing  consultancy to Industries.​<br>
The Foundation is recognized by Directorate of Vanaspati, Vegetable Oils
and   Fats,   Ministry   of   Consumer   Affairs   Food   and   Public   Distribution,
Government of India under the   Edible Oils Packaging (Regulation ) Order
1998 as a competent testing laboratory and the Government of the National
Capital   Territory   of   Delhi,   under   the   Delhi   Edible   Oils   order   1998   as   a
competent   testing   laboratory.   The   foundation   was   duly   registered   under
Foreign   Contribution   (Regulation)   Act   1976   in   2005.   It   is   approved   by
Income  Tax   Dept,   Govt.   of   India   for   receiving   donation   under  ATG/35(I),
section(ii).<br>
It is ISO-9001 2015 certified organisation.<br>
We ensure that all our research and analytical outputs are  reliable, efficient
and accurate at par with international standards.</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- about-style-three end -->

 