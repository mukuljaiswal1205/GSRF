 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Add New Post</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">New Post</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <!-- Main content -->
    <section class="content">
   
        <?php
			$Success = $this->session->flashdata('Success');
			$Error = $this->session->flashdata('Error');
			if(isset($Success))
			{
				echo $Success;
			}
			else
			{
				echo $Error;
			}
			?>
        <div class="col-md-10">
                    <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">New</h3>
              </div>
              <!-- /.card-header -->
			 
              <!-- form start -->
              <form role="form" method="Post" action="Add_New_Post_data" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Title</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter email" name="Title" value="<?php echo set_value('Title'); ?>" >
                     <?php echo form_error('Title', '<div class="error">', '</div>'); ?>
                  </div>
                 
                  <div class="form-group">
                    <label for="exampleInputFile">Image</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file" class="custom-file-input" id="exampleInputFile" name="image">
                        <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                      </div>
                      <div class="input-group-append">
                        <span class="input-group-text" id="">Upload</span>
                      </div>
                    </div>
                  </div>
                   <div class="form-group">
                    <label for="exampleInputPassword1">Description</label>
                    <textarea  placeholder="Place some text here"
                          style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" name="Description"></textarea>
                          <?php echo form_error('Description', '<div class="error">', '</div>'); ?>
                  </div>
                 
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
        </div>
          
      
    </section>
    <!-- /.content -->
  </div>
  