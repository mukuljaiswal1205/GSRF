 
  <!-- page-title -->
    <section class="page-title centred" style="background-image: url(<?php echo base_url('images/weserve/field-and-sky.jpg'); ?>);  background-repeat: no-repeat;
  background-size: cover; ">
        <div class="container">
            <div class="content-box">
                <div class="title"> Cosmetics And Personal</div>
                <ul class="bread-crumb">
                    <li><a href="index.html">Home</a></li>
                    <li>Cosmetics And Personal </li>
                </ul>
            </div>
        </div>
    </section>
    <!-- page-title end -->


    <!-- about-style-mission -->
    <section class="about-style-three">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 title-column">
                    <div class="title-box">
                        <div class="sec-title" style="margin-bottom:2px;">Cosmetics And Personal</div>
                        <div class="title-text">Services</div>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 content-column">
                    <div class="content-box">
                       
                        <div class="text" style="margin-top:25px;"> 

<div id="divHeader">
<p>Eurofins Cosmetics & Personal Care is a global network of accredited laboratories offering a full range of services; enabling you to gain access to national and international markets in a cost and time efficient manner.</p>
</div>
<div class="row">
      <div class="col-md-4">
          <img src="images/weserve/products-btn.jpg"
      </div>
</div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- about-style-mission end -->
	   