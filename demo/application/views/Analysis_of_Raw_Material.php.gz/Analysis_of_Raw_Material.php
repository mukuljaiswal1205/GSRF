 
<style>
ul, li {

   
}
.about-style-three {
    
    padding: 50px 0px 50px 0px;
}
</style>
    <!-- page-title -->
    <section class="page-title centred" style="background-image: url(<?php echo base_url('asserts/images/background/page-title.jpg'); ?>);">
        <div class="container">
            <div class="content-box">
                <div class="title"> About us</div>
                <ul class="bread-crumb">
                    <li><a href="index.html">Home</a></li>
                    <li>About us </li>
                </ul>
            </div>
        </div>
    </section>
    <!-- page-title end -->


    <!-- about-style-mission -->
    <section class="about-style-three">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-5 col-sm-12 title-column">
                    <div class="title-box">
                        <div class="sec-title" style="margin-bottom:2px;">Our Services</div>
                        <div class="title-text">GSRF</div>
                    </div>
                </div>
                <div class="col-lg-7 col-md-7 col-sm-12 content-column">
                    <div class="content-box">
                       
                        <div class="text" style="margin-top:25px;"> 
						 <p style="text-align:justify;">Ganesh Scientific Research Foundation, a ISO 9001-2015, full fledged   se
research and analytical laboratory specializes in the areas of Human food,
according   to   FSSAI   regulations,   Animal   feed,   Raw   materials   for   food
production,   processing   materials,   bye-products   etc.     We   provide   a   wide
range   of   services   to   various  Industries.  Expertise  of   the  Analytical  testing
Department   enables   the   industries   to   adopt   the   most   cost   effective   and
efficient approach.</p>
						</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- about-style-mission end -->
	   
	<!-- about-style-vision  -->
     <section class="about-style-three" style="background: #eaeaea57;" >
        <div class="container"  >
             <div style="text-align:center;">
			            
			 </div>
			<div class="row">
			
                <div class="col-lg-6 col-md-6 col-sm-12 title-column">
                    <div class="title-box">
					     <h2> Analytical   Testing   according   to   FSSAI,BIS,CODEX,AGMARK   or specific requirements</h2>
                        <ul style="margin-top:20px;">
						  <li style="list-style: decimal;line-height:30px;"> Edible Oils,Fat   and   Oil   products   like   Vanaspati,   Margarine,   Bahery   fat, Interesterified fats etc.</li>
						   <li style="list-style: decimal;line-height:30px;"> Dairy products</li>
						   <li style="list-style: decimal;line-height:30px;"> Spices and Condiments, Essential Oils</li>
						   <li style="list-style: decimal;line-height:30px;"> Cereals and Pulses</li>
						   <li style="list-style: decimal;line-height:30px;"> Raw  and  processed  fruits  and vegetables,  Fruit products like   Jam, Jelly, Pickle, Sugar and Confectionery, Honey</li>
						   <li style="list-style: decimal;line-height:30px;">Proprietory Foods</li>
						   <li style="list-style: decimal;line-height:30px;">Energy foods</li>
						   <li style="list-style: decimal;line-height:30px;">Oilseeds, oilcakes</li>
						   <li style="list-style: decimal;line-height:30px;">Animal Feeds</li>
						   <li style="list-style: decimal;line-height:30px;">Cosmetic Products</li>
						   <li style="list-style: decimal;line-height:30px;">Food Additives</li>
						   <li style="list-style: decimal;line-height:30px;">Alcoholic and non-alcoholic beverages</li>
						   <li style="list-style: decimal;line-height:30px;">Biscuit, Namkeen, Snacks and Ready to Eat Foods</li>
						   <li style="list-style: decimal;line-height:30px;">Packaging materials</li>
						 
						</ul>
                        
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 title-column">
                    <div class="title-box">
					     <h2 >Special Parameters we test</h2>
                        <ul style="margin-top:100px;">
						  <li style="list-style: decimal; line-height:30px;"> Detailed   Fatty   acid   Composition   of   Oils   and   fats   including   trans   fatty acids.</li>
						   <li style="list-style: decimal;line-height:30px;"> Shelf Life of Food products</li>
						   <li style="list-style: decimal;line-height:30px;"> Analysis of Vitamins, Sterol, Tocopherol, Tocotrienol Oryzanol and other Micronutrients.</li>
						   <li style="list-style: decimal;line-height:30px;"> Complete Nutritional Information </li>
						   <li style="list-style: decimal;line-height:30px;"> Testing of Afatoxin /  Mycotoxins </li>
						   <li style="list-style: decimal;line-height:30px;"> Testing of Food Allergens </li>
						   <li style="list-style: decimal;line-height:30px;"> Testing of antibiotics, Tetra Cycline, Choramphenicol, sulfonamides etc. </li>
						   <li style="list-style: decimal;line-height:30px;"> Detection and quantification of pesticides, insecticides  </li>
						   <li style="list-style: decimal;line-height:30px;"> Analysis of Heavy Metal Residue  </li>
						   <li style="list-style: decimal;line-height:30px;"> Analysis of Synthetic dyes and added color </li>
						   <li style="list-style: decimal;line-height:30px;">  Analysis of GMO Materials </li>
						   <li style="list-style: decimal;line-height:30px;"> Testing of Food Pathogen, E-Coli, Listeria, Salmonella Yeast and Moulds etc. </li>
						   <li style="list-style: decimal;line-height:30px;"> Skin   i rritation    and   Corroslon   testing   for   Cosmetic   products   (In   Vitro testing as per OECD guidelines 439, 431) </li>
						   <li style="list-style: decimal;line-height:30px;"> Stat-of-the art services for qualing assurance of raw materials, finished products, by e products of food and related industries</li>
 
						  
						 
						</ul>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- about-style-vision  end -->
	 <!-- about-style-mission -->
    <section class="about-style-three">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 title-column">
                    <div class="title-box">
                        <div class="sec-title" style="margin-bottom:2px;">Our core Team </div>
                        <div class="title-text">About us</div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 content-column">
                    <div class="content-box">
                       
                        <div class="text" style=""> 
						  <img src="<?php echo base_url('asserts/images/aboutus/strength.jpg'); ?>" alt="" style="padding:50px;padding-bottom:0px;width:100%;">
						</div>
                    </div>
                </div>
				 <div class="col-lg-6 col-md-6 col-sm-12 content-column">
                    <div class="content-box">
                       
                        <div class="text" style=" padding:50px;"> 
						  <ul> 
							<li style="list-style: disc;line-height: 40px;"> Highly qualified and experienced, dedicated Scientists. </li>
							<li style="list-style: disc;line-height: 40px;"> Wide range of Instrumentation</li>
							<li style="list-style: disc;line-height: 40px;"> Providing   critical research and analytical information which the clients need   for   trouble   shooting,   quality   control,   internal   requirements   and applications.​</li>
						  </ul>
						</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
	 <!-- about-style-mission -->
    <section class="about-style-three">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 title-column">
                    <div class="title-box">
                        <div class="sec-title" style="margin-bottom:2px;">METHODOLOGIES </div>
                        <div class="title-text">About us</div>
                    </div>
                </div>
				 <div class="col-lg-6 col-md-6 col-sm-12 content-column">
                    <div class="content-box">
                       
                        <div class="text" style=" padding:50px;"> 
						  <ul> 
							<li style="list-style: disc;line-height: 40px;"> GSRF   adheres   strictly   to   Indian   and   International   Standards   like  AOAC, Codex,   BIS,   FSSAI,   OECD   in   order   to   yield   accurate   and   efficient   test results with minimum uncertainty levels.</li>
							<li style="list-style: disc;line-height: 40px;">Instruments are Calibrated through authorized agencies</li>
					      </ul>
						</div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 content-column">
                    <div class="content-box">
                       
                        <div class="text" style=""> 
						  <img src="<?php echo base_url('asserts/images/aboutus/appoldt.jpg'); ?>" alt="" style="padding:50px;width:100%;">
						</div>
                    </div>
                </div>
				
            </div>
        </div>
    </section>

 