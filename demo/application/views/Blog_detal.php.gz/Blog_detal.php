

    <!-- page-title -->
    <section class="page-title centred" style="background-image: url(<?php echo base_url('asserts/images/background/page-title.jpg'); ?>);">
        <div class="container">
            <div class="content-box">
                <div class="title">Blog Details</div>
                <ul class="bread-crumb">
                    <li><a href="index.html">Home</a></li>
                    <li>Blog Details</li>
                </ul>
            </div>
        </div>
    </section>
    <!-- page-title end -->


    <!-- blog-details -->
    <section class="blog-details sidebar-page-container gray-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-8 col-sm-12 content-side">
                    <div class="blog-details-content default-blog-content">
                        <div class="">
                            <div class="inner-content">
                                <figure class="image-box"><img height="400px" src="<?php echo base_url(); ?>asserts/Post/<?php echo $row['id']."/".$row['Image']; ?>" alt=""></figure>
                                <div class="content-box">
                                    <div class="content-style-one">
                                        <div class="title"><?php echo $row['title']; ?></div>
                                        <ul class="info-content">
                                            <li>by <span>admin</span></li>
                                            <li><?php echo nice_date($row['Date'],'D-M-Y'); ?></li>
                                        </ul>
                                        <div class="text">
                                            <p><?php echo $row['content']; ?></p>
                                        </div>
                                    </div>
                                    <div class="post-share-option">
                                        <div class="clearfix">
                                            <div class="share-content">
                                                <div class="text">Share:</div>
                                                <ul class="social">
                                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                    <li><a href="#"><i class="fa fa-rss"></i></a></li>
                                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                                </ul>
                                            </div>
                                            <ul class="comment">
                                                <li><i class="fa fa-heart-o"></i>350</li>
                                                <li><i class="fa fa-comments-o"></i>30</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                         
                        </div>
                        
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-12 sidebar-side">
                    <div class="sidebar default-sidebar-content">
                        
                        <div class="sidebar-post sidebar-widget">
                            <div class="sidebar-title"><h4>Latest Posts</h4></div>
                            <div class="post-inner">
							<?php foreach($Posts as $Post) { ?>
                                <div class="single-post">
                                    <h5><a href="blog-details.html"><?php echo $Post['title']; ?></a></h5>
                                    <div class="post-date"><i class="flaticon-small-calendar"></i><?php echo nice_date($Post['Date'],'D-M-Y'); ?></div>
                                </div>
							<?php } ?>   
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- blog-details end -->


