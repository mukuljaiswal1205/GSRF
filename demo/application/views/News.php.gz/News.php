  <!-- page-title -->
    <section class="page-title centred" style="background-image: url(<?php echo base_url('asserts/images/background/page-title.jpg'); ?>);">
        <div class="container">
            <div class="content-box">
                <div class="title">Blog Details</div>
                <ul class="bread-crumb">
                    <li><a href="index.html">Home</a></li>
                    <li>Blog Details</li>
                </ul>
            </div>
        </div>
    </section>
    <!-- page-title end -->
	

    <!-- news-style-two -->
    <section class="news-style-two">
        <div class="container">
            <div class="title-box centred">
                <div class="sec-title">News</div>
                <div class="top-text">Latest News</div>
            </div>
            <div class="row">
			<?php 
				foreach($rows as $row)
				{
				?>
				
					<!--Start single blog post-->
					<div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
						<div class="single-blog-post">
							<div class="img-holder">
								<img width="100%" height="250px" src="<?php echo base_url(); ?>asserts/Post/<?php echo $row['id']."/".$row['Image']; ?>" alt="Awesome Image">
								<div class="categorie-button">
									<a class="btn-one" href="Blog_detail/<?php echo $row['id']; ?>"></a>    
								</div>
							</div>
							<div class="text-holder">
								<div class="meta-box">
									<ul class="meta-info">
										<li>By admin</li>
										<li><a href="Blog_detail/<?php echo $row['id']; ?>"><?php echo nice_date($row['Date'],'d/m/Y'); ?></a></li>
									</ul>    
								</div>
								<h3 class="blog-title"><a href="#"><?php echo $row['title']; ?></a></h3> 
								<div class="text-box">
									<p><?php echo word_limiter($row['content'],20); ?></p>
								</div>
								<div class="readmore-button">
									<a class="btn-two" href="Blog_detail/<?php echo $row['id']; ?>">Continue Reading<span class="flaticon-next"></span></a>
								</div>  
							</div>
						</div>
					</div>
					<!--End single blog post-->
			<?php 		
				}
			?>	
            </div>
        </div>
    </section>
    
    

    <!-- news-section -->