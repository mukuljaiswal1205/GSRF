export interface Position {
    left: number;
    top: number;
}
