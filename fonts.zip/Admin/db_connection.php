
<?php 
$con = mysqli_connect("localhost","ReidiusExibition","P@ssword@123#","ReidiusExibition");
?>